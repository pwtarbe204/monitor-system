def checkUrl():
    return 0
def checkUrls():
    return 0
